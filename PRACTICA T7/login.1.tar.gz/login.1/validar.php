<?php

$conexion =  new mysqli('localhost', 'maj009', '', 'usuarios');
$consulta = "SELECT * FROM datos;";
$resultado = $conexion->query($consulta);
while($fila = $resultado->fetch_assoc())
{
	if($fila['usuario'] == $_GET['u'])
	{
		echo 'Existe';
	}
	else
	{
		echo 'No existe';
	}
}

?>
